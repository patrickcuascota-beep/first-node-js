#!/bin/bash
# Actualiza e instala dependencias
sudo -i
sudo apt-get update
sudo apt-get install -y nginx curl

# Instala Node.js y npm
sudo curl -fsSL https://deb.nodesource.com/setup_20.x -o nodesource_setup.sh
sudo bash nodesource_setup.sh
sudo apt-get install -y nodejs
sudo apt install -y build-essential

# Crea una aplicación de Node.js
sudo -i
sudo mkdir -p /var/www/app
sudo chmod -R 755 /var/www/app
cd /var/www/app
cat <<EOL | sudo tee index.js > /dev/null
const http = require('http');
const hostname = 'localhost';
const port = 3000;

const server = http.createServer((req, res) => {
  res.statusCode = 200;
  res.setHeader('Content-Type', 'text/plain');
  res.end('Hello World, Welcome to Devops!');
});

server.listen(3000, '0.0.0.0', () => {
  console.log(\`Server running at http://\${hostname}:\${port}/\`);
});
EOL

# Instala pm2 para gestionar la aplicación
sudo -i
sudo npm install -g pm2@latest
sudo pm2 start /var/www/app/index.js
sudo pm2 startup systemd
#sudo env PATH=$PATH:/usr/bin /usr/lib/node_modules/pm2/bin/pm2 startup systemd -u ubuntu --hp /home/ubuntu
sudo pm2 save

# Configura Nginx como proxy para la aplicación

sudo -i
cd /etc/nginx/sites-available/
sudo mv default olddefault_org
cat <<EOL | sudo tee /etc/nginx/sites-available/example.com >/dev/null
server {
  listen 80;
  server_name example.com;
  
  location / {
    proxy_pass http://localhost:3000;
    proxy_http_version 1.1;
    proxy_set_header Upgrade \$http_upgrade;
    proxy_set_header Connection 'upgrade';
    proxy_set_header Host \$host;
    proxy_cache_bypass \$http_upgrade;
  }
}
EOL

sudo ln -s /etc/nginx/sites-available/example.com /etc/nginx/sites-enabled/

sudo rm /etc/nginx/sites-enabled/default

sudo nginx -t
#sudo systemctl enable nginx
sudo systemctl start nginx